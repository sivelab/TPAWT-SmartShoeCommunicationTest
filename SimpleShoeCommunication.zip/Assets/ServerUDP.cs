﻿using UnityEngine;
using System.Collections;
using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.IO;
using System.Threading;

public class ServerUDP : MonoBehaviour {

	public UDPSendPacket udpSendPacket;
	Thread receiveThread;
	UdpClient client;
	public int port;
	IPEndPoint sender;
	private string stringData = "Waiting to receive data";
	// Use this for initialization
	void Start () {
		port = 2050;
		


		
   }	
	
	void startServer()
	{
		if (!serverStarted)
		{
			receiveThread = new Thread(new ThreadStart(ReceiveData));
			receiveThread.IsBackground = true;
			receiveThread.Start ();
			serverStarted = true;
		}
	}
	// Update is called once per frame
	public float globalTime;
	void Update () {
		globalTime = Time.time;
		testing = udpSendPacket.getTesting();
		trialNumber = udpSendPacket.getTrialNumber();
		if (testing&&!serverStarted)
		{
			startServer();
		}
		//guiText.text = stringData;

		
		/*
      print("Message received from {0}:" + sender.ToString());
      print(Encoding.ASCII.GetString(data, 0, data.Length));

      string welcome = "Welcome to my test server";
      data = Encoding.ASCII.GetBytes(welcome);
      newsock.Send(data, data.Length, sender);

      while(true)
      {
         data = newsock.Receive(ref sender);
       
         Console.WriteLine(Encoding.ASCII.GetString(data, 0, data.Length));
         newsock.Send(data, data.Length, sender);
      }
      */
	}
	private string writeLocationLeft= "C:\\SmartShoe\\DataLeft.txt";
	private string writeLocationRight= "C:\\SmartShoe\\DataRight.txt";
	public GUIStyle testStyles;
	private bool startRecording = false;
	private bool serverStarted = false;

	private bool testing = false;
	private int trialNumber = -1;
	private string serverStatus = "";
	void OnGUI(){
		GUI.TextField(new Rect(450, 10, 100, 20), "Receiving Port", 25,testStyles);
		port = Convert.ToInt32(GUI.TextField(new Rect(550, 10, 60, 20), port.ToString(), 25));
		if (GUI.Button(new Rect(450, 30, 100, 20), "Start Server"))
		{
			startServer();
		}
		GUI.TextField(new Rect(450, 50, 200, 20), "Save Leftfoot to File", 50, testStyles);
		writeLocationLeft= GUI.TextField(new Rect(450, 70, 200, 20), writeLocationLeft, 50);
		GUI.TextField(new Rect(450, 90, 200, 20), "Save Rightfoot to File", 50, testStyles);
		writeLocationRight= GUI.TextField(new Rect(450, 110, 200, 20), writeLocationRight, 50);

		if (GUI.Button(new Rect(450, 130, 100, 20), "Start Saving"))
		{
			startRecording = true;
		}
		if (GUI.Button(new Rect(550, 130, 100, 20), "Stop Saving"))
		{
			startRecording = false;
		}
		if (!serverStarted && startRecording)//error, start server!
		{
			GUI.TextField(new Rect(450,150, 100, 20), "Error:  Server not Started",testStyles);
		}
		else if (serverStarted && startRecording)//error, start server!
		{
			GUI.TextField(new Rect(450, 150, 100, 20), "Recording!",testStyles);
		}
		else if (!serverStarted && !startRecording)//error, start server!
		{
			GUI.TextField(new Rect(450, 150, 100, 20), "Server Not Started",testStyles);
		}
		else if (serverStarted && !startRecording)//error, start server!
		{
			GUI.TextField(new Rect(450, 150, 100, 20), "Server Ready!",testStyles);
		}
		GUI.TextField(new Rect(450, 170, 100, 20), serverStatus,testStyles);
	}

	float pastTime = 0;
	private void ReceiveData()
	{
		client = new UdpClient(port);
		while (true)
		{
			try{
				IPEndPoint anyIP = new IPEndPoint (IPAddress.Any, 0);
      			byte[] data = new byte[81];
				data = client.Receive(ref anyIP);
				stringData = ByteArrayToString(data);
				//Debug.Log("dl:"+data.Length + " " + (globalTime-pastTime));
				//pastTime = globalTime;
				if (startRecording)
				{
					System.IO.File.AppendAllText(writeLocationLeft, stringData+ "\r\n");
				}
				if(testing)
				{
					try{
						System.IO.File.AppendAllText(writeLocationLeft, "trialNumber:"+trialNumber+": Data:"+stringData+ "\r\n");
						serverStatus = "Saving Data from the test!";
					}
					catch (Exception e){
						serverStatus = "tried and failed to save testing data.  Perhaps bad file location?";
					}
				}
				//stringData=data;
				string header = stringData.Substring(0,8);
				//Debug.Log("MessageGot: "+ stringData);
				//guiText.text = "Message Received!";
			}
			catch(Exception e){
				Debug.LogError(e);
				//guiText.text = e.ToString ();
			}
		}
	}
	public static string ByteArrayToString(byte[] ba)
	{
		string hex = BitConverter.ToString(ba);
		return hex.Replace("-"," ");
	}
	private void OnDisable() 
	{ 
		if ( receiveThread!= null) 
			receiveThread.Abort(); 
		if(client != null)
		client.Close(); 
	} 

}
